<?php
    $user1 = "Default 1";
    $user2 = "Default 2";

    $color1 = "Rouge";
    global $color1;

    $tab = [[],[],[],[],[],[],[]];
    global $tab;

    $nbLine = 6;
    $nbCols = 7;


    if (isset($_POST["user1"]) && isset($_POST["user2"]) && isset($_POST["colors"])){
        $GLOBALS["user1"] = $_POST["user1"];
        $GLOBALS["user2"] = $_POST["user2"];
        $GLOBALS["color1"] = $_POST["colors"];

        $GLOBALS["nbLine"] = 6;
        $GLOBALS["nbCols"] = 7;

        initGame();

        $_SESSION["user1"] = $GLOBALS["user1"];
        $_SESSION["user2"] = $GLOBALS["user2"];
        $_SESSION["color1"] = $GLOBALS["color1"];
        $_SESSION["nbLine"] = $GLOBALS["nbLine"];
        $_SESSION["nbCols"] = $GLOBALS["nbCols"];
        $_SESSION["tab"] = $GLOBALS["tab"];

        $mysqli = new mysqli("localhost","root","","bdd_php");
        $id = 1;
        $caseColonne = 0;
        $caseLigne = 0;
        $valeur = 0;

        $req = " INSERT INTO puissance4 ('id','caseColonne','caseLigne','valeur') VALUES ('$id', $caseColonne, $caseLigne,'$valeur' ); ";
        $req2 = "SELECT * FROM puissance4";
        $result = $mysqli->query($req) ;
        echo $result;
    }

    function initGame() {
        for ($i = 0; $i < getLine(); ++$i) {
            for ($j = 0; $j < getCols(); ++$j) {
                $tab[$i][$j] = 0;
            }
        }

        /*
        foreach ($tab as $sousTab) {
            foreach ($sousTab as $cell) {
                echo $cell;
            }
            echo "<br>";
        }
         */

    }

    function switchColor() {
        if ($color1 == 'Rouge') {
            $color1 = 'Jaune';
        } else {
            $color1 = 'Rouge';
        }
    }

    function currentPlayer() {
        if (getColor1() == 'Jaune') {
            return getPlayer2();
        } else {
            return getPlayer1();
        }
    }

    function getPlayer1() {
        return $GLOBALS["user1"];
    }

    function getPlayer2() {
        return $GLOBALS["user2"];
    }

    function getColor1() {
        return $GLOBALS["color1"];
    }

    function getLine() {
        return $GLOBALS["nbLine"];
    }

    function getCols() {
        return $GLOBALS["nbCols"];
    }
?>
