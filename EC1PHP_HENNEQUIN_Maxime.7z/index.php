<?php
    require ('model.php');
    require ('view.php');
?>
