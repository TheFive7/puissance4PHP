<html>
    <head>
		<title>Puissance 4</title>
    </head>
	<body>
		<?php
			require 'model.php';
		?>
		<script>
			function ToColor(elem, color){
				if(color == 'rouge')	elem.innerHtml = '<img id="cel01" src="Rouge.png">';
				else					elem.firstElementChild.src = color + ".png";
			}
			
			function ToColorById(id, color){
				document.getElementById(id).src = color + ".png";
			}
			
			function send(param){
				document.getElementById('myform').submit();
			}
		</script>
        
		<table style="background-color: blue;">
			<?php
				for ($i = 0; $i < getLine(); ++$i) {
			?>
				<tr>
					<?php
						for ($j = 0; $j < getCols(); ++$j) {
					?>
						<td><a href="javascript:void(0);" onclick="javascript:ToColorById('<?php echo 'cell'.$i.$j ?>', '<?php echo 'Rouge' ?>');"><img id="<?php echo "cell".$i.$j ?>" src="Vide.png"></a></td>
					<?php } ?>
				</tr>
			<?php } ?>
		</table>

		<center> <h2> Au tour de <?php echo currentPlayer() ?> </h2> </center>
		<br/>
		<br/>
	</body>
</html>