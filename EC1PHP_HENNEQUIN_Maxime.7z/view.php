<html>
    <head>
		<title>Puissance 4</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=*, initial-scale=1.0">
    </head>
	<body>
		<center><h2>Jeu puissance 4 </h2></center>

        <form method ="POST" action="game.php">
            <label for="user1">Nom</label>
            <input name = "user1" type="text"> <br> <br>

            <label for="user2">Nom</label>
            <input name = "user2" type="text"> <br> <br>

            <label for="colors">Choisir la couleur du joueur 1:</label>
            <select name="colors">
                <option value="red">Rouge</option>
                <option value="yellow">Jaune</option>
            </select>

            <br> <br>

            <button type = submit> Jouer </button>
        </form>
	</body>
</html>